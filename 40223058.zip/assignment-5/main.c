//nadiagholami 40223058
#include <stdio.h>
int main() {
    int n,i,j;//n is the length of our array
    i=0;
    printf("type the length of your array :");
    scanf("%d",&n);
    char a[n];
    printf("please type a continuous text expression with the length of %d",n);
    scanf("%s",&a);
    while (i<n){
        if (a[i]==a[i+1]){//in here we check whether any two consecutive elements of our array are the same or not 
        //if yes we tend to delete both of them
            for (j=i;j<n-1;j++){
                a[j]=a[j+2];//by doing this we shift every part of array in order to delete the same elements
            }
        printf("%s\n",a);
        i=0;
        }
        else 
            i++;
        
    
    }

return 0;


}