//nadia gholami 40223058
#include <stdio.h>
#include <math.h>
void solver(double a,double b,double c,int *t,double *p1,double *p2);
int main(){
    int tedad=0;
    int *pointerTedad=&tedad;
    double rootNo1;
    double *pointerRootNo1=&rootNo1;
    double rootNo2;
    double *pointerRootNo2=&rootNo2;
    double x,y,z;//x,y and z are the coefficients of our equation
    printf("type the first number:");
    scanf("%lf",&x);
    printf("type the second number:");
    scanf("%lf",&y);
    printf("type the third number:");
    scanf("%lf",&z);
    if (x==0 && y==0)//x^2's and x's coefficient can not be 0 at the same time
        printf("wrong numbers");
    else//if the given numbers were right go and run the solver function for x,y and z
        solver(x,y,z,pointerTedad,pointerRootNo1,pointerRootNo2);
        if (*pointerTedad==0)
            printf("this equation has no real roots");
        if (*pointerTedad==1)
            printf("the equation has one root which is : %lf",*pointerRootNo1);
        if (*pointerTedad==2)
            printf("the equation has two roots which are : %lf and %lf",*pointerRootNo1,*pointerRootNo2);

    
    return 0;
}
void solver(double a,double b,double c,int *t,double *p1,double *p2){
    double teta= (b*b)-(4*a*c);
    //if (teta<0)
        //printf("this equation has no real roots");
    if (teta==0){
        *p1=(-b)/(2*a);
        *t=1;}
        //printf("the equation has one root which is : %lf",root);}
    if (teta>0){
        *t=2;
        *p1=((-b)+(sqrt(teta)))/(2*a);
        *p2=((-b)-(sqrt(teta)))/(2*a);
        //printf("the equation has two roots which are : %lf and %lf",firstRoot,secondRoot);
    }
    
}




